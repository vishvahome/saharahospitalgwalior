<div class="cc_meta_control">
	<p>
		<textarea name="_inpost_head_script[synth_header_script]" rows="5" style="width:98%;"><?php if(!empty($meta['synth_header_script'])) echo $meta['synth_header_script']; ?></textarea>
	</p>
	<p><?php _e('Copy and paste the code snippet to add bot to this post or page', 'collectchat'); ?>.</p>
</div>
