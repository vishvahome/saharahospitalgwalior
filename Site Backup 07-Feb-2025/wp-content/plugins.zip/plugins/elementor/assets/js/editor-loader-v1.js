/*! elementor - v3.27.0 - 03-02-2025 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!*******************************************************!*\
  !*** ../core/editor/loader/v1/js/editor-loader-v1.js ***!
  \*******************************************************/


window.elementor.start();
/******/ })()
;
//# sourceMappingURL=editor-loader-v1.js.map